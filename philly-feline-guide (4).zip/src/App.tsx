import { Coffee, Heart, MapPin, Stethoscope, ArrowLeft, ExternalLink } from 'lucide-react';
import { useState } from 'react';

type ViewState = 'home' | 'cafes' | 'shelters' | 'vets' | 'resources';

export default function App() {
  const [currentView, setCurrentView] = useState<ViewState>('home');

  const renderContent = () => {
    switch (currentView) {
      case 'cafes':
        return (
          <div className="flex flex-col w-full gap-3 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <h2 className="text-[28px] font-balsamiq font-bold text-[#5a5a5a] text-center mb-4">Best Cat Cafes</h2>
            <PlaceCard name="Purr Cat Cafe" desc="A colorful feline lounge and adoption center on East Passyunk." url="https://www.purrphilly.com/purr-cat-cafe" address="1007 E Passyunk Ave, Philadelphia, PA 19147" />
            <PlaceCard name="Kawaii Cat Cafe" desc="Philly's first cat cafe! A Japanese-inspired feline lounge in Queen Village." url="https://www.kawaiicatcafe.com/" address="750 S 4th St, Philadelphia, PA 19147" />
            <PlaceCard name="Le Cat Cafe" desc="Brewerytown's finest feline lounge. Reservations recommended!" url="https://lecatcafe.org/" address="2713 W Girard Ave, Philadelphia, PA 19130" />
            <PlaceCard name="Get a Gato" desc="South Philly's newest cat cafe featuring local pastries and adoptable cats." url="https://www.getagato.com/" address="638 Christian St, Philadelphia, PA 19147" />
          </div>
        );
      case 'shelters':
        return (
          <div className="flex flex-col w-full gap-3 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <h2 className="text-[28px] font-balsamiq font-bold text-[#5a5a5a] text-center mb-4">Adoption Shelters</h2>
            <PlaceCard name="PAWS (Philly Animal Welfare)" desc="The city's largest rescue partner and provider of basic vet care." url="https://phillypaws.org/" address="100 N 2nd St, Philadelphia, PA 19106" />
            <PlaceCard name="Morris Animal Refuge" desc="America's first animal shelter, located right in Center City." url="https://www.morrisanimalrefuge.org/" address="1242 Lombard St, Philadelphia, PA 19147" />
            <PlaceCard name="ACCT Philly" desc="The region's largest animal care and control service provider." url="https://acctphilly.org/" address="111 W Hunting Park Ave, Philadelphia, PA 19140" />
            <PlaceCard name="Project MEOW" desc="West Philadelphia's dedicated trap-neuter-return and rescue group." url="https://www.projectmeow.org/" address="West Philadelphia, Philadelphia, PA" />
            <PlaceCard name="Green Street Rescue" desc="Fairmount-based rescue focusing on street cats and fostering." url="https://greenstreetrescue.org/" address="Fairmount, Philadelphia, PA" />
            <PlaceCard name="Philly Community Cats Council" desc="Advocating for the community cats of Philadelphia." url="https://www.phillycats.org/" address="Philadelphia, PA" />
          </div>
        );
      case 'vets':
        return (
          <div className="flex flex-col w-full gap-3 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <h2 className="text-[28px] font-balsamiq font-bold text-[#5a5a5a] text-center mb-4">Feline-Friendly Vets</h2>
            <PlaceCard name="The Cat Doctor" desc="A feline-only veterinary hospital located in the Art Museum area." url="https://www.thecatdoctor.com/" address="535 N 22nd St, Philadelphia, PA 19130" />
            <PlaceCard name="Center City Veterinary Hospital" desc="Highly rated full-service vet in Old City." url="https://www.centercityvet.com/" address="37 S 3rd St, Philadelphia, PA 19106" />
            <PlaceCard name="VCA Cat Hospital of Philadelphia" desc="Specialized feline care right in Rittenhouse Square." url="https://vcahospitals.com/cat-hospital-of-philadelphia" address="226 S 20th St, Philadelphia, PA 19103" />
          </div>
        );
      case 'resources':
        return (
          <div className="flex flex-col w-full gap-3 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <h2 className="text-[28px] font-balsamiq font-bold text-[#5a5a5a] text-center mb-4">Stray Cat Resources</h2>
            <PlaceCard name="ACCT Philly Community Cats" desc="Resources for Trap-Neuter-Return (TNR) and working cat programs." url="https://acctphilly.org/programs/community-cats/" address="111 W Hunting Park Ave, Philadelphia, PA 19140" />
            <PlaceCard name="Stray Cat Relief Fund" desc="Helping stray and feral cats in the South Philly area." url="https://straycatrelieffund.org/" address="South Philadelphia, Philadelphia, PA" />
            <PlaceCard name="Temple Cats" desc="Caring for the community cats around Temple University's campus." url="https://www.templecats.org/" address="Temple University, Philadelphia, PA" />
          </div>
        );
      default:
        return (
          <div className="flex flex-col w-full gap-4 animate-in fade-in duration-500">
            <button 
              onClick={() => setCurrentView('cafes')}
              className="bg-[#8ba38b] hover:bg-[#7a927a] text-white px-[25px] py-[18px] rounded-[20px] text-center font-bold text-[1.1rem] shadow-[0_4px_6px_rgba(0,0,0,0.08)] transition-all flex items-center justify-center gap-3 cursor-pointer"
            >
              <Coffee className="w-5 h-5" />
              Best Cat Cafes
            </button>
            
            <button 
              onClick={() => setCurrentView('shelters')}
              className="bg-[#8ba38b] hover:bg-[#7a927a] text-white px-[25px] py-[18px] rounded-[20px] text-center font-bold text-[1.1rem] shadow-[0_4px_6px_rgba(0,0,0,0.08)] transition-all flex items-center justify-center gap-3 cursor-pointer"
            >
              <Heart className="w-5 h-5" />
              Local Adoption Shelters
            </button>
            
            <button 
              onClick={() => setCurrentView('vets')}
              className="bg-[#8ba38b] hover:bg-[#7a927a] text-white px-[25px] py-[18px] rounded-[20px] text-center font-bold text-[1.1rem] shadow-[0_4px_6px_rgba(0,0,0,0.08)] transition-all flex items-center justify-center gap-3 cursor-pointer"
            >
              <Stethoscope className="w-5 h-5" />
              Feline-Friendly Vets
            </button>
            
            <button 
              onClick={() => setCurrentView('resources')}
              className="bg-[#8ba38b] hover:bg-[#7a927a] text-white px-[25px] py-[18px] rounded-[20px] text-center font-bold text-[1.1rem] shadow-[0_4px_6px_rgba(0,0,0,0.08)] transition-all flex items-center justify-center gap-3 cursor-pointer"
            >
              <MapPin className="w-5 h-5" />
              Stray Cat Resources
            </button>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-[#f4f1eb] text-[#1a1a1a] font-sans p-6 flex flex-col items-center">
      
      <div className="w-full max-w-md flex flex-col items-center pt-8 pb-12 relative">
        
        {/* Back Button (only show if not on home) */}
        {currentView !== 'home' && (
          <button 
            onClick={() => setCurrentView('home')}
            className="absolute top-8 left-0 p-2 text-[#7d7d7d] hover:text-[#5a5a5a] transition-colors flex items-center gap-1 font-bold"
          >
            <ArrowLeft className="w-5 h-5" />
            Back
          </button>
        )}

        {/* Title */}
        <h1 className="text-[46px] font-balsamiq font-bold text-[#5a5a5a] leading-[1.1] text-center mb-6">
          Philly Feline<br/>Guide
        </h1>

        {/* Custom SVG Skyline with Cat */}
        <div className="w-full mb-6">
          <svg viewBox="0 0 500 200" className="w-full h-auto stroke-[#7d7d7d] fill-none opacity-80" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            {/* Base continuous line for buildings and cat */}
            <path d="
              M 10 180
              L 10 130 L 30 110 L 50 130 L 50 180
              L 50 140 L 60 140 L 80 70 L 100 140 L 110 140 L 110 180
              L 110 150 L 130 150 L 130 100 L 140 100 L 140 60 L 145 40 L 150 60 L 150 100 L 160 100 L 160 150 L 180 150 L 180 180
              L 200 180
              C 200 160, 205 150, 215 150
              L 220 120 L 235 140
              C 245 135, 265 135, 275 140
              L 290 120 L 295 150
              C 305 150, 310 160, 310 180
              L 320 180
              L 320 140 L 340 120 L 360 140 L 360 180
              L 360 130 L 370 130 L 370 60 L 380 60 L 380 40 L 400 40 L 400 60 L 410 60 L 410 130 L 420 130 L 420 180
              L 490 180
            " />
            
            {/* Liberty Place Chevrons */}
            <path d="M 65 110 L 80 70 L 95 110 M 70 125 L 80 95 L 90 125" strokeWidth="1.5" />
            
            {/* City Hall Clock */}
            <circle cx="145" cy="80" r="6" strokeWidth="1.5" />
            <path d="M 145 76 L 145 80 L 148 80" strokeWidth="1.5" />
            
            {/* Cat Face Details */}
            <path d="M 240 155 Q 245 150 250 155 M 260 155 Q 265 150 270 155" strokeWidth="2.5" />
            <path d="M 255 165 L 255 170" strokeWidth="2.5" />
            
            {/* Cat Whiskers */}
            <path d="M 225 155 L 205 150 M 225 165 L 205 165 M 285 155 L 305 150 M 285 165 L 305 165" strokeWidth="1.5" />
            
            {/* Comcast Center Lines */}
            <path d="M 390 40 L 390 180" strokeWidth="1.5" />
          </svg>
        </div>

        {/* Dynamic Content Area */}
        {renderContent()}

        {/* Cat Face Drawing at the Bottom */}
        <div className="mt-12 flex flex-col items-center">
          <svg viewBox="0 0 120 60" className="w-24 h-auto stroke-[#7d7d7d] fill-none opacity-80" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
            {/* Head outline */}
            <path d="
              M 0 60
              C 0 40, 5 30, 15 30
              L 20 0 L 35 20
              C 45 15, 65 15, 75 20
              L 90 0 L 95 30
              C 105 30, 110 40, 110 60
              L 120 60
            " />
            {/* Eyes */}
            <path d="M 40 35 Q 45 30 50 35 M 60 35 Q 65 30 70 35" strokeWidth="2.5" />
            {/* Nose/Mouth */}
            <path d="M 55 45 L 55 50" strokeWidth="2.5" />
            {/* Whiskers */}
            <path d="M 25 35 L 5 30 M 25 45 L 5 45 M 85 35 L 105 30 M 85 45 L 105 45" strokeWidth="1.5" />
          </svg>
        </div>

      </div>
    </div>
  );
}

// Helper component for the list items
function PlaceCard({ name, desc, url, address }: { name: string, desc: string, url: string, address: string }) {
  const mapUrl = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(name + ' ' + address)}`;

  return (
    <div className="bg-white/60 backdrop-blur-sm border-2 border-[#8ba38b] p-4 rounded-[20px] flex flex-col gap-2 hover:bg-white/80 transition-colors group">
      <div className="flex justify-between items-start">
        <a 
          href={url} 
          target="_blank" 
          rel="noopener noreferrer"
          className="font-balsamiq font-bold text-[#5a5a5a] text-[18px] hover:text-[#8ba38b] transition-colors flex items-center gap-2 no-underline"
        >
          {name}
          <ExternalLink className="w-4 h-4" />
        </a>
      </div>
      <p className="text-[#4a4a4a] text-sm font-medium leading-snug">{desc}</p>
      <a 
        href={mapUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="text-[#8ba38b] text-xs font-bold hover:underline flex items-center gap-1 mt-1 no-underline"
      >
        <MapPin className="w-3 h-3" />
        View on Map
      </a>
    </div>
  );
}
